﻿
namespace TPP.Seminarios.Concurrente.Seminario6 {

    class Program {
        static void Main(string[] args) {
            const int milisPensar = 0, milisComer = 0;
            Tenedor[] tenedor = new Tenedor[5];
            for (int i = 0; i < tenedor.Length; i++)
                tenedor[i] = new Tenedor(i);

            new Filosofo(0, milisPensar, milisComer, 0, 1);
            new Filosofo(1, milisPensar, milisComer, 1, 2);
            new Filosofo(2, milisPensar, milisComer, 2, 3);
            new Filosofo(3, milisPensar, milisComer, 3, 4);
            new Filosofo(4, milisPensar, milisComer, 4, 0);
        }
    }
}
