﻿namespace TPP.Seminarios.Concurrente.Seminario6
{
    class Tenedores
    {
        /// <summary>
        /// Indican si están siendo usados (por omisión falso, no usados)
        /// </summary>
        private bool[] tenedores = new bool[5];

        /// <summary>
        /// Solicita dos tenedores
        /// </summary>
        /// <param name="izquierdo">Número del tenedor izquierdo</param>
        /// <param name="derecho">Número del tenedor derecho</param>
        /// <returns>Si se concedió o no el par de tenedores</returns>
        public bool ObtenerTenedores(int izquierdo, int derecho)
        {
            lock (this.tenedores)
            {
                if (!tenedores[izquierdo] && !tenedores[derecho])
                {
                    tenedores[izquierdo] = tenedores[derecho] = true;
                    return true;
                }
                else
                    return false;
            }
        }
        /// <summary>
        /// Devuelve los tenedores
        /// </summary>
        /// <param name="izquierdo">Número del tenedor izquierdo</param>
        /// <param name="derecho">Número del tenedor derecho</param>
        public void SoltarTenedores(int izquierdo, int derecho)
        {
            lock (this.tenedores)
            {
                tenedores[izquierdo] = tenedores[derecho] = false;
            }
        }
    }
}