﻿using System;
using System.Text;
using System.Diagnostics;

namespace TPP.Laboratory.ObjectOrientation.Lab03 {

    public class Stack {

        public static void Main() {
            Debug.Assert(false, "Message of the assertion not fulfilled ");
        }

    }

}