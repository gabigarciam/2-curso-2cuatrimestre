#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Ex 1
"""
import numpy as np

a = np.array([1,3,7])
print('a = ')
print(a)
#%%
b = np.array([[2,4,3],[0,1,6]])
print('\nb = ')
print(b)
#%%
c = np.ones(3)
print('\nc = ')
print(c)
#%%
d = np.zeros(4)
print('\nd = ')
print(d)
#%%
e = np.zeros((3,2))
print('\ne = ')
print(e)
#%%
f = np.ones((3,4))
print('\nf = ')
print(f)